import React, { Component } from 'react';
import Booking from './components/Booking';

class App extends Component {
  render() {
    return (
      <div >
        <h2>Hotel Booking</h2>
        <Booking />
      </div>
    );
  }
}

export default App;
